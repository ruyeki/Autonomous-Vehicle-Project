#include <jsoncpp/json/json.h>
#include <jsoncpp/json/reader.h>
#include <jsoncpp/json/writer.h>
#include <jsoncpp/json/value.h>
#include <string>
#include <cstring>

#include <iostream>
#include "leftmotorcycle.h"
#include <jsonrpccpp/server/connectors/httpserver.h>
#include "middlecar.h"
#include <jsonrpccpp/client/connectors/httpclient.h>
#include <stdio.h>

#include <time.h>
#include "JvTime.h"

// File includes
#include "vehicle.h"
#include "car.h"
#include "motorcycle.h"
#include "gps.h"
#include "person.h"
#include "thing.h"
#include "decision.h"

// So we don't have to type jsonrpc:: or std:: for some standard functions
using namespace jsonrpc;
using namespace std;
//-------------------------------------------------------------------------------------------//

//---------------------------------------------------------------------------------------------------//
Car carInEmergency {};
Motorcycle LMotor {};
Motorcycle incomingMotor {};
Decision decisionL {};
Decision decisionR {};
Decision decision {};



class MotorCycleServer : public leftMotorcycle
{
public:
  MotorCycleServer(AbstractServerConnector &connector, serverVersion_t type);
  virtual Json::Value move(const std::string& action,
                           const std::string& class_id,
                           const Json::Value& json_object,
                           const std::string& object_id);
};

MotorCycleServer::MotorCycleServer(AbstractServerConnector &connector, serverVersion_t type): leftMotorcycle(connector, type)
{
  std::cout << "CarReturnServer created" << "\n";
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////

Json::Value MotorCycleServer::move (const std::string& action, 
                               const std::string& class_id,
                               const Json::Value& json_object,
                               const std::string& object_id)
{
  Json::Value result;
  std::string strJson;

  std::cout << "Moving Object...\n";
  if (class_id != "Car" && class_id != "Decision")
    {
      result["status"] = "failed";
    }

  if (object_id.empty())
    {
      result["status"] = "failed";
    }

  if ((json_object.isNull() == true) || (json_object.isObject() == false)) {
      result["status"] = "failed";
  }
    

  if(class_id == "Car") {
    Car * lv_car_ptr;
    lv_car_ptr = new Car {};
    lv_car_ptr->JSON2Object(json_object);

    cout << "\n \n" << lv_car_ptr->dump2JSON().toStyledString() << "\n \n";
    
    carInEmergency = *lv_car_ptr;

  }

  if(class_id == "Decision") {
    Decision * lv_decision_ptr;
    lv_decision_ptr = new Decision {};
    lv_decision_ptr->JSON2Object(json_object);

    cout << "\n \n" << lv_decision_ptr->dump2JSON().toStyledString() << "\n \n";
    
    decision = *lv_decision_ptr;

  }

  if(class_id == "Motorcycle") {
    Motorcycle * lv_motorcycle_ptr;
    lv_motorcycle_ptr = new Motorcycle {};
    lv_motorcycle_ptr->JSON2Object(json_object);

    cout << "\n \n" << lv_motorcycle_ptr->dump2JSON().toStyledString() << "\n \n";
    
    incomingMotor = *lv_motorcycle_ptr;

  }

    result["status"] = "successful";
  

  return result;
}



int main()
{
  string description_1;
  double weight_1;
  double height_1;
  double integrity_1;
  double airbag_1;
  Person person1_1;
  Person person2_1;
  Person person3_1;
  Person person4_1;
  GPS location_1;
  // int passengersnum;
  // bool emergency;
Car MCar(){}
 //where all the cin and cout variables go
// MCar(description_1, weight_1, height_1, integrity_1, airbag_1, person1_1, person2_1, person3_1, person4_1, location_1);
cout << "Enter type of Car" << endl;
getline(cin, MCar(description_1));
cout << "Enter wieght of Car" << endl;
getline(cin, MCar.weight_1);
cout << "Enter height of Car" << endl;
getline(cin, MCar.Height_1);
cout << "structural integrity" << endl;
getline(cin, MCar.integrity_1);
cout << "airbag" << endl;
getline(cin, MCar.airbag_1);
cout << "name of Person1" << endl;
getline(cin, MCar.person1_1);
cout << "name of Person2" << endl;
getline(cin, MCar.person2_1);
cout << "name of Person3" << endl;
getline(cin, MCar.person3_1);
cout << "name of Person4" << endl;
getline(cin, MCar.person4_1);
cout << "location" << endl;
getline(cin, MCar.location_1);
// this->argdescription = argdescription_1;
// this->weight = weight_1;
// this->height = Height_1;
// this->structural_integrity = structural_integrity_1;
// this->airbag = airbag_1;
// this->person1 = person1_1;
// this->person2 = person2_1;
// this->person3 = person3_1;
// this->person4 = person4_1;
// this->location = location_1;

  // Now it's time to do RPC (CLIENT) stuff *************************************************************************************************


  HttpClient httpclient1("http://127.0.0.1:0001");
  middleCar mycar1(httpclient1, JSONRPC_CLIENT_V2);
  Json::Value jsonV1;

  HttpClient httpclient2("http://127.0.0.1:0002");
  middleCar mycar2(httpclient2, JSONRPC_CLIENT_V2);
  Json::Value jsonV2;
  
  /*Cin and cout statements 
  string argDescription;
  double weight;
  double height;
  double structural_integ;
  double airbag;
  Person person1;
  Person person2;
  Person person3;
  Person person4;
  GPS location;
  int passengersnum;
  bool emergency;

  cout<<"What's in front of left motorcycle? " <<endl;
 cout<<"Weight: ";
 cin>>weight;
 cout<<"Height: ";
 cin>>height;
 Car(argDescription,weight, height, structural_integ, airbag, person1, person2, person3, person4, location, passengersnum, emergency);
 */

//making the 3x3 matrix
int matrix[3][3];
for(int x=0;x<3;x++)
    {
        for(int y=0;y<3;y++)
        {
            matrix[x][y]= 0;
        }
    }

    for(int x=0;x<3;x++)
    {
        for(int y=0;y<3;y++)  
            cout<<matrix[x][y]; 
    cout<<endl; 
    }
 
  try {
    jsonV1 = mycar1.move("move", "Car", MCar.dump2JSON(), "00000342");
    // I know the order of parameters is unusual, but RPC does things in alphabetical order
    //moves copy of the car you create from cin and cout and moves over to 
  }
  catch (JsonRpcException &e) {
    cerr << e.what() << endl;
  }
  std::cout << jsonV1.toStyledString() << "\n";

  try {
    jsonV2 = mycar2.move("move", "Car", MCar.dump2JSON(), "00000343");
    // I know the order of parameters is unusual, but RPC does things in alphabetical order
  }
  catch (JsonRpcException &e) {
    cerr << e.what() << endl;
  }
  std::cout << jsonV2.toStyledString() << "\n";
  // End of RPC (CLIENT) stuff *****************************************************************************************************

  // Begin Server -------------------------------------------------------------------------------------------------




  // string verdict;
  // cout<<"What car do you want to hit"<<endl;
  // cin>>verdict;
  // cout << verdict << " hi" <<endl;

  HttpServer httpserver4(0004);
  MotorCycleServer s(httpserver4, JSONRPC_SERVER_V2);
  s.StartListening();
  std::cout << "Awaiting information from ./middleCarReturn...\n";
  std::cout << "Enter = Kill Server" << "\n";
  getchar();
  s.StopListening();

  // End Server ---------------------------------------------------------------------------------------------------

  // One more client phase to send the directions to the motorcycles ______________________________

  try {
    jsonV1 = mycar1.move("move", "Decision", decisionL.dump2JSON(), "82305823");
    // I know the order of parameters is unusual, but RPC does things in alphabetical order
  }
  catch (JsonRpcException &e) {
    cerr << e.what() << endl;
  }
  std::cout << jsonV1.toStyledString() << "\n";

  try {
    jsonV2 = mycar2.move("move", "Decision", decisionR.dump2JSON(), "359276196");
    // I know the order of parameters is unusual, but RPC does things in alphabetical order
  }
  catch (JsonRpcException &e) {
    cerr << e.what() << endl;
  }
  std::cout << jsonV2.toStyledString() << "\n";

  // ______________________________________________________________________________________________

  return 0;
}